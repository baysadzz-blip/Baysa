import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { ShieldCheck, Lock, X, RefreshCw, Smartphone } from 'lucide-react';

export const TwoFactorModal: React.FC = () => {
  const { is2FAModalOpen, setIs2FAModalOpen, verify2FA } = useApp();
  const [code, setCode] = useState<string>('');
  const [error, setError] = useState<string>('');
  const [trustedDevice, setTrustedDevice] = useState<boolean>(true);

  if (!is2FAModalOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const success = verify2FA(code);
    if (!success) {
      setError('Please enter a valid 6-digit verification code (e.g. 482910).');
    }
  };

  const handleQuickFill = () => {
    setCode('482910');
    setError('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 overflow-y-auto bg-black/60 backdrop-blur-xs">
      <div
        className="relative w-full max-w-sm bg-white rounded-2xl shadow-2xl border border-neutral-200 overflow-hidden my-auto p-6 space-y-6"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-neutral-200 pb-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center">
              <Lock className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-display text-sm font-bold text-neutral-900">
                Two-Factor Verification
              </h3>
              <p className="text-[11px] text-neutral-500">2FA Security Challenge</p>
            </div>
          </div>
          <button
            onClick={() => setIs2FAModalOpen(false)}
            className="p-1 text-neutral-400 hover:text-neutral-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="text-xs text-neutral-600 space-y-2">
          <p>
            A 6-digit authentication token has been dispatched to your trusted authenticator & mobile device.
          </p>
          <div className="p-2.5 bg-neutral-50 rounded-xl border border-neutral-200 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Smartphone className="w-4 h-4 text-neutral-500" />
              <span className="font-medium text-neutral-800">Demo Token: 482910</span>
            </div>
            <button
              type="button"
              onClick={handleQuickFill}
              className="text-xs font-semibold text-neutral-900 bg-neutral-200 hover:bg-neutral-300 px-2 py-0.5 rounded transition-colors"
            >
              Fill Code
            </button>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-1">
            <label className="text-xs font-semibold text-neutral-800 block text-center">
              Enter 6-Digit Code
            </label>
            <input
              type="text"
              maxLength={6}
              value={code}
              onChange={(e) => {
                setCode(e.target.value.replace(/\D/g, ''));
                setError('');
              }}
              placeholder="482910"
              className="w-full text-center font-mono text-2xl tracking-[0.35em] py-2 px-3 border border-neutral-300 rounded-xl outline-none focus:border-neutral-900 font-bold"
              autoFocus
            />
            {error && <p className="text-[11px] text-red-600 text-center pt-1">{error}</p>}
          </div>

          <label className="flex items-center gap-2 text-xs text-neutral-600 cursor-pointer pt-1">
            <input
              type="checkbox"
              checked={trustedDevice}
              onChange={(e) => setTrustedDevice(e.target.checked)}
              className="rounded text-neutral-900 focus:ring-neutral-900"
            />
            <span>Remember this device for 30 days</span>
          </label>

          <button
            type="submit"
            className="w-full py-2.5 bg-neutral-900 hover:bg-neutral-800 text-white text-xs font-semibold rounded-xl transition-colors shadow-xs flex items-center justify-center gap-2"
          >
            <ShieldCheck className="w-4 h-4" />
            <span>Verify & Authenticate</span>
          </button>
        </form>

        <div className="text-center pt-1">
          <button
            type="button"
            onClick={handleQuickFill}
            className="text-[11px] text-neutral-500 hover:text-neutral-800 flex items-center gap-1 mx-auto"
          >
            <RefreshCw className="w-3 h-3" />
            <span>Didn't receive a code? Resend SMS</span>
          </button>
        </div>

      </div>
    </div>
  );
};
