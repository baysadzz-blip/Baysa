import React from 'react';
import { ShieldCheck, MapPin, Heart } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const Footer: React.FC = () => {
  const { setCurrentView, setIsMapModalOpen, selectedNeighborhood } = useApp();

  return (
    <footer className="bg-white border-t border-neutral-200 mt-20 text-neutral-600">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 pb-10 border-b border-neutral-100">
          
          {/* Brand Col */}
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-md bg-neutral-900 text-white flex items-center justify-center font-bold text-xs">
                M
              </div>
              <span className="font-display text-base font-bold text-neutral-900">
                Mercato Local
              </span>
            </div>
            <p className="text-xs text-neutral-500 leading-relaxed">
              Decentralized neighborhood commerce network connecting resident artisans, home bakers, plant enthusiasts, and local stores.
            </p>
            <div className="text-xs text-neutral-400 font-mono">
              Active Zone: {selectedNeighborhood === 'all' ? 'Citywide Hubs' : selectedNeighborhood}
            </div>
          </div>

          {/* Nav links */}
          <div className="space-y-2 text-xs">
            <h4 className="font-semibold text-neutral-900 font-display">Discover Local</h4>
            <ul className="space-y-2">
              <li>
                <button
                  onClick={() => setCurrentView('marketplace')}
                  className="hover:text-neutral-900 transition-colors"
                >
                  Featured Artisan Listings
                </button>
              </li>
              <li>
                <button
                  onClick={() => setCurrentView('stores')}
                  className="hover:text-neutral-900 transition-colors"
                >
                  Neighborhood Storefronts
                </button>
              </li>
              <li>
                <button
                  onClick={() => setIsMapModalOpen(true)}
                  className="hover:text-neutral-900 transition-colors"
                >
                  Interactive Walking Map
                </button>
              </li>
              <li>
                <button
                  onClick={() => setCurrentView('dashboard')}
                  className="hover:text-neutral-900 transition-colors"
                >
                  Merchant & Maker Hub
                </button>
              </li>
            </ul>
          </div>

          {/* Safety & Escrow */}
          <div className="space-y-2 text-xs">
            <h4 className="font-semibold text-neutral-900 font-display">Trust & Protection</h4>
            <ul className="space-y-2 text-neutral-500">
              <li className="flex items-center gap-1.5 text-neutral-700">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                <span>Mercato Escrow Vault Guarantee</span>
              </li>
              <li>Verified Physical Pickup QR Passes</li>
              <li>Designated Public Meetup Zones</li>
              <li>Two-Factor Account Authentication</li>
              <li>Dual-Sided Community Reviews</li>
            </ul>
          </div>

          {/* Local Districts */}
          <div className="space-y-2 text-xs">
            <h4 className="font-semibold text-neutral-900 font-display">Neighborhood Quarters</h4>
            <ul className="space-y-1.5 text-neutral-500">
              <li>Eastside Arts District</li>
              <li>Downtown Historic Core</li>
              <li>Greenwood Hill</li>
              <li>Riverfront Quarter</li>
              <li>Southpark Commons</li>
            </ul>
          </div>

        </div>

        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-neutral-400">
          <div className="flex items-center gap-1">
            <span>© 2026 Mercato Local. Built for community resilience and local trade.</span>
          </div>
          <div className="flex items-center gap-4 text-[11px]">
            <span>Privacy</span>
            <span>·</span>
            <span>Community Guidelines</span>
            <span>·</span>
            <span>Seller Terms</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
