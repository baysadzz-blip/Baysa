import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { X, Plus, Package, MapPin, Truck, DollarSign } from 'lucide-react';
import { ItemCondition, DeliveryType } from '../types';

const SAMPLE_IMAGE_OPTIONS = [
  { label: 'Ceramic Stoneware', url: '/src/assets/images/ceramic_dripper_set_1791629923487.jpg' },
  { label: 'Artisan Bakery', url: '/src/assets/images/artisan_bakery_box_1791629946050.jpg' },
  { label: 'Leather Goods', url: '/src/assets/images/leather_tote_bag_1791629934193.jpg' },
  { label: 'Botanical Plants', url: '/src/assets/images/botanical_plant_shop_1791629956860.jpg' }
];

export const NewItemModal: React.FC = () => {
  const { isNewItemModalOpen, setIsNewItemModalOpen, addItem, currentUser } = useApp();

  const [title, setTitle] = useState<string>('');
  const [price, setPrice] = useState<string>('');
  const [category, setCategory] = useState<string>('Artisan & Craft');
  const [condition, setCondition] = useState<ItemCondition>('Handcrafted');
  const [stock, setStock] = useState<number>(1);
  const [description, setDescription] = useState<string>('');
  const [selectedImage, setSelectedImage] = useState<string>(SAMPLE_IMAGE_OPTIONS[0].url);
  const [pickupAddress, setPickupAddress] = useState<string>(
    '88 Studio Alley, Bay 3 (Eastside Arts District)'
  );
  const [deliveryOptions, setDeliveryOptions] = useState<DeliveryType[]>([
    'local_pickup',
    'neighborhood_courier'
  ]);

  if (!isNewItemModalOpen) return null;

  const toggleDelivery = (opt: DeliveryType) => {
    if (deliveryOptions.includes(opt)) {
      if (deliveryOptions.length > 1) {
        setDeliveryOptions(deliveryOptions.filter((d) => d !== opt));
      }
    } else {
      setDeliveryOptions([...deliveryOptions, opt]);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const parsedPrice = parseFloat(price);
    if (!title.trim() || !parsedPrice || parsedPrice <= 0) return;

    addItem({
      title: title.trim(),
      price: parsedPrice,
      category,
      condition,
      image: selectedImage,
      description: description.trim() || 'Handmade and locally sourced by neighborhood artisan.',
      neighborhood: currentUser.neighborhood,
      distanceMiles: 0.5,
      sellerId: currentUser.id,
      sellerName: `${currentUser.name} (Local Maker)`,
      sellerAvatar: currentUser.avatar,
      sellerRating: 5.0,
      stock,
      deliveryOptions,
      pickupAddress: pickupAddress.trim()
    });

    setIsNewItemModalOpen(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto bg-black/60 backdrop-blur-xs">
      <div
        className="relative w-full max-w-lg bg-white rounded-2xl shadow-2xl border border-neutral-200 overflow-hidden my-auto max-h-[90vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 border-b border-neutral-200 flex items-center justify-between bg-neutral-50/80">
          <div className="flex items-center gap-2">
            <Package className="w-4 h-4 text-neutral-900" />
            <h3 className="font-display text-sm font-bold text-neutral-900">
              List an Item for Local Neighbors
            </h3>
          </div>
          <button
            onClick={() => setIsNewItemModalOpen(false)}
            className="p-1 text-neutral-400 hover:text-neutral-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 overflow-y-auto text-xs">
          
          <div>
            <label className="font-semibold text-neutral-800 block mb-1">
              Item Title
            </label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g., Handmade Ceramic Pour-Over Cone"
              className="w-full px-3 py-2 border border-neutral-300 rounded-lg outline-none font-medium"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="font-semibold text-neutral-800 block mb-1">
                Price (USD)
              </label>
              <div className="flex items-center border border-neutral-300 rounded-lg overflow-hidden bg-white">
                <span className="px-2.5 text-neutral-400 font-semibold">$</span>
                <input
                  type="number"
                  required
                  step="0.01"
                  min="0.5"
                  value={price}
                  onChange={(e) => setPrice(e.target.value)}
                  placeholder="38.00"
                  className="w-full py-2 pr-3 outline-none font-mono font-medium"
                />
              </div>
            </div>

            <div>
              <label className="font-semibold text-neutral-800 block mb-1">
                Stock Quantity
              </label>
              <input
                type="number"
                min="1"
                value={stock}
                onChange={(e) => setStock(parseInt(e.target.value) || 1)}
                className="w-full px-3 py-2 border border-neutral-300 rounded-lg outline-none font-mono font-medium"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="font-semibold text-neutral-800 block mb-1">
                Category
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full px-3 py-2 border border-neutral-300 rounded-lg outline-none font-medium bg-white"
              >
                <option value="Artisan & Craft">Artisan & Craft</option>
                <option value="Food & Bakery">Food & Bakery</option>
                <option value="Home & Plants">Home & Plants</option>
                <option value="Vintage & Fashion">Vintage & Fashion</option>
                <option value="Tech & Gear">Tech & Gear</option>
              </select>
            </div>

            <div>
              <label className="font-semibold text-neutral-800 block mb-1">
                Condition
              </label>
              <select
                value={condition}
                onChange={(e) => setCondition(e.target.value as ItemCondition)}
                className="w-full px-3 py-2 border border-neutral-300 rounded-lg outline-none font-medium bg-white"
              >
                <option value="Handcrafted">Handcrafted</option>
                <option value="Brand New">Brand New</option>
                <option value="Like New">Like New</option>
                <option value="Good">Good</option>
              </select>
            </div>
          </div>

          {/* Image preset selector */}
          <div className="space-y-1.5">
            <label className="font-semibold text-neutral-800 block">
              Listing Photography Asset
            </label>
            <div className="grid grid-cols-4 gap-2">
              {SAMPLE_IMAGE_OPTIONS.map((img) => (
                <button
                  key={img.label}
                  type="button"
                  onClick={() => setSelectedImage(img.url)}
                  className={`relative aspect-square rounded-lg overflow-hidden border-2 transition-all ${
                    selectedImage === img.url
                      ? 'border-neutral-900 ring-2 ring-neutral-900/20'
                      : 'border-transparent opacity-70 hover:opacity-100'
                  }`}
                >
                  <img
                    src={img.url}
                    alt={img.label}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="font-semibold text-neutral-800 block mb-1">
              Meetup & Pickup Location
            </label>
            <input
              type="text"
              required
              value={pickupAddress}
              onChange={(e) => setPickupAddress(e.target.value)}
              placeholder="e.g. 88 Studio Alley, Bay 3"
              className="w-full px-3 py-2 border border-neutral-300 rounded-lg outline-none font-medium"
            />
          </div>

          <div>
            <label className="font-semibold text-neutral-800 block mb-1">
              Item Details & Story
            </label>
            <textarea
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Describe materials, origin, dimensions, care instructions..."
              className="w-full px-3 py-2 border border-neutral-300 rounded-lg outline-none font-medium"
            />
          </div>

          {/* Fulfillment Modes */}
          <div className="space-y-1.5 pt-1">
            <label className="font-semibold text-neutral-800 block">
              Available Delivery & Meetup Options
            </label>
            <div className="flex flex-wrap gap-2">
              {[
                { id: 'local_pickup', label: 'Local In-Person Pickup' },
                { id: 'neighborhood_courier', label: 'Neighborhood Courier' },
                { id: 'same_day_dropoff', label: 'Same-Day Dropoff' }
              ].map((opt) => (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => toggleDelivery(opt.id as DeliveryType)}
                  className={`px-3 py-1.5 rounded-lg border font-medium transition-colors ${
                    deliveryOptions.includes(opt.id as DeliveryType)
                      ? 'border-neutral-900 bg-neutral-900 text-white'
                      : 'border-neutral-200 text-neutral-700 bg-white hover:bg-neutral-50'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          {/* Submit */}
          <button
            type="submit"
            className="w-full py-3 bg-neutral-900 hover:bg-neutral-800 text-white text-xs font-semibold rounded-xl transition-colors shadow-xs"
          >
            Publish Listing Immediately
          </button>

        </form>
      </div>
    </div>
  );
};
