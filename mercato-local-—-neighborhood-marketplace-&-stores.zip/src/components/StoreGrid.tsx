import React from 'react';
import { useApp } from '../context/AppContext';
import { StoreCard } from './StoreCard';
import { Store as StoreIcon, RotateCcw } from 'lucide-react';

export const StoreGrid: React.FC = () => {
  const { filteredStores, setSearchQuery, setSelectedNeighborhood, setRadiusMiles } = useApp();

  if (filteredStores.length === 0) {
    return (
      <div className="py-20 text-center max-w-md mx-auto px-4">
        <div className="w-12 h-12 mx-auto rounded-full bg-neutral-100 flex items-center justify-center text-neutral-400 mb-4">
          <StoreIcon className="w-6 h-6" />
        </div>
        <h3 className="font-display text-lg font-semibold text-neutral-900 mb-2">
          No neighborhood stores found
        </h3>
        <p className="text-sm text-neutral-500 mb-6 leading-relaxed">
          Try expanding your distance radius or selecting another neighborhood.
        </p>
        <button
          onClick={() => {
            setSearchQuery('');
            setSelectedNeighborhood('all');
            setRadiusMiles(15);
          }}
          className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-neutral-900 bg-neutral-100 hover:bg-neutral-200 rounded-lg transition-colors"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Reset Filters</span>
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="font-display text-xl font-bold text-neutral-900">
            Neighborhood Storefronts & Maker Studios
          </h2>
          <p className="text-xs text-neutral-500 mt-0.5">
            Verified local businesses operating in brick-and-mortar locations and resident maker spaces.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 sm:gap-8">
        {filteredStores.map((store) => (
          <StoreCard key={store.id} store={store} />
        ))}
      </div>
    </div>
  );
};
