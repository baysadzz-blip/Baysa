import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  MapPin,
  Check,
  Sparkles,
  ShoppingBag,
  Store,
  ArrowRight,
  ShieldCheck
} from 'lucide-react';
import { NEIGHBORHOODS } from '../data/mockData';

const INTERESTS = [
  'Wild Sourdough & Bakes',
  'Wheel-Thrown Ceramics',
  'Rare Indoor Foliage',
  'Vegetable-Tanned Leather',
  'Analog Cameras & Audio',
  'Restored Cast Iron & Tools'
];

export const OnboardingModal: React.FC = () => {
  const { isOnboardingOpen, completeOnboarding } = useApp();

  const [step, setStep] = useState<number>(1);
  const [selectedNeighborhood, setSelectedNeighborhood] = useState<string>('Eastside Arts District');
  const [selectedInterests, setSelectedInterests] = useState<string[]>([
    'Wild Sourdough & Bakes',
    'Wheel-Thrown Ceramics'
  ]);
  const [role, setRole] = useState<'buyer' | 'seller'>('buyer');

  if (!isOnboardingOpen) return null;

  const toggleInterest = (interest: string) => {
    if (selectedInterests.includes(interest)) {
      setSelectedInterests(selectedInterests.filter((i) => i !== interest));
    } else {
      setSelectedInterests([...selectedInterests, interest]);
    }
  };

  const handleFinish = () => {
    completeOnboarding({
      neighborhood: selectedNeighborhood,
      interests: selectedInterests,
      role
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 overflow-y-auto bg-black/60 backdrop-blur-xs">
      <div
        className="relative w-full max-w-lg bg-white rounded-2xl shadow-2xl border border-neutral-200 overflow-hidden my-auto p-6 sm:p-8 space-y-6"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Step indicator */}
        <div className="flex items-center justify-between border-b border-neutral-200 pb-4">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-neutral-900 text-white flex items-center justify-center font-bold text-xs">
              M
            </div>
            <div>
              <span className="font-display text-sm font-bold text-neutral-900">
                Welcome to Your Local Community
              </span>
              <div className="text-[11px] text-neutral-500">Step {step} of 3</div>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            {[1, 2, 3].map((s) => (
              <div
                key={s}
                className={`w-5 h-1.5 rounded-full transition-colors ${
                  s === step ? 'bg-neutral-900' : s < step ? 'bg-emerald-600' : 'bg-neutral-200'
                }`}
              />
            ))}
          </div>
        </div>

        {/* Step 1: Neighborhood */}
        {step === 1 && (
          <div className="space-y-4">
            <div className="space-y-1">
              <h2 className="font-display text-xl font-bold text-neutral-900">
                Where is your home base?
              </h2>
              <p className="text-xs text-neutral-600">
                Select your neighborhood to prioritize listings within walking and biking distance.
              </p>
            </div>

            <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
              {NEIGHBORHOODS.filter((n) => n.id !== 'all').map((n) => (
                <button
                  key={n.id}
                  type="button"
                  onClick={() => setSelectedNeighborhood(n.name)}
                  className={`w-full p-3 rounded-xl border text-left transition-all flex items-center justify-between ${
                    selectedNeighborhood === n.name
                      ? 'border-neutral-900 bg-neutral-900 text-white'
                      : 'border-neutral-200 bg-white text-neutral-800 hover:bg-neutral-50'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <MapPin className="w-4 h-4 shrink-0 opacity-80" />
                    <div>
                      <div className="text-xs font-semibold leading-tight">{n.name}</div>
                      <div className="text-[11px] opacity-80 mt-0.5">
                        {n.activeStoresCount} stores · {n.activeItemsCount} items nearby
                      </div>
                    </div>
                  </div>
                  {selectedNeighborhood === n.name && (
                    <Check className="w-4 h-4 shrink-0" />
                  )}
                </button>
              ))}
            </div>

            <button
              onClick={() => setStep(2)}
              className="w-full py-2.5 bg-neutral-900 hover:bg-neutral-800 text-white text-xs font-semibold rounded-xl transition-colors flex items-center justify-center gap-2 shadow-xs"
            >
              <span>Continue</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {/* Step 2: Interests */}
        {step === 2 && (
          <div className="space-y-4">
            <div className="space-y-1">
              <h2 className="font-display text-xl font-bold text-neutral-900">
                What local goods interest you?
              </h2>
              <p className="text-xs text-neutral-600">
                Customize your neighborhood feed with your favorite artisan goods.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-2">
              {INTERESTS.map((interest) => {
                const selected = selectedInterests.includes(interest);
                return (
                  <button
                    key={interest}
                    type="button"
                    onClick={() => toggleInterest(interest)}
                    className={`p-3 rounded-xl border text-left text-xs font-medium transition-all flex flex-col justify-between ${
                      selected
                        ? 'border-neutral-900 bg-neutral-900 text-white'
                        : 'border-neutral-200 bg-white text-neutral-700 hover:bg-neutral-50'
                    }`}
                  >
                    <span>{interest}</span>
                    <span className="text-[10px] opacity-70 mt-2 font-mono">
                      {selected ? '✓ Selected' : '+ Tap to add'}
                    </span>
                  </button>
                );
              })}
            </div>

            <div className="flex items-center gap-3 pt-2">
              <button
                onClick={() => setStep(1)}
                className="px-4 py-2 text-xs text-neutral-600 hover:text-neutral-900"
              >
                Back
              </button>
              <button
                onClick={() => setStep(3)}
                className="flex-1 py-2.5 bg-neutral-900 hover:bg-neutral-800 text-white text-xs font-semibold rounded-xl transition-colors flex items-center justify-center gap-2 shadow-xs"
              >
                <span>Continue</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}

        {/* Step 3: Role & Welcome Reward */}
        {step === 3 && (
          <div className="space-y-4">
            <div className="space-y-1">
              <h2 className="font-display text-xl font-bold text-neutral-900">
                How will you participate?
              </h2>
              <p className="text-xs text-neutral-600">
                You can buy and sell on the same account at any time.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setRole('buyer')}
                className={`p-4 rounded-xl border text-left transition-all ${
                  role === 'buyer'
                    ? 'border-neutral-900 bg-neutral-50 ring-1 ring-neutral-900'
                    : 'border-neutral-200 hover:bg-neutral-50/50'
                }`}
              >
                <ShoppingBag className="w-5 h-5 text-neutral-800 mb-2" />
                <div className="text-xs font-bold text-neutral-900">Discover & Buy</div>
                <div className="text-[11px] text-neutral-500 mt-1">
                  Shop local bakes, plants, craft studio tableware & pre-loved goods.
                </div>
              </button>

              <button
                type="button"
                onClick={() => setRole('seller')}
                className={`p-4 rounded-xl border text-left transition-all ${
                  role === 'seller'
                    ? 'border-neutral-900 bg-neutral-50 ring-1 ring-neutral-900'
                    : 'border-neutral-200 hover:bg-neutral-50/50'
                }`}
              >
                <Store className="w-5 h-5 text-neutral-800 mb-2" />
                <div className="text-xs font-bold text-neutral-900">Open Store & Sell</div>
                <div className="text-[11px] text-neutral-500 mt-1">
                  List handcrafted products, surplus tools, or neighborhood bakery boxes.
                </div>
              </button>
            </div>

            {/* Welcome Gift Card */}
            <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200 flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-emerald-600 text-white flex items-center justify-center shrink-0">
                <Sparkles className="w-4 h-4" />
              </div>
              <div className="text-xs text-emerald-950">
                <div className="font-bold">$10 Local Neighborhood Voucher</div>
                <div className="text-[11px] text-emerald-800">
                  Automatically credited to your Mercato Wallet on completion!
                </div>
              </div>
            </div>

            <div className="flex items-center gap-3 pt-2">
              <button
                onClick={() => setStep(2)}
                className="px-4 py-2 text-xs text-neutral-600 hover:text-neutral-900"
              >
                Back
              </button>
              <button
                onClick={handleFinish}
                className="flex-1 py-3 bg-neutral-900 hover:bg-neutral-800 text-white text-xs font-bold rounded-xl transition-colors shadow-xs"
              >
                Claim $10 & Enter Neighborhood
              </button>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
