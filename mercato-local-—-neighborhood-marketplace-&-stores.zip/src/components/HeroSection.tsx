import React from 'react';
import { useApp } from '../context/AppContext';
import { Search, MapPin, SlidersHorizontal, ShieldCheck, Zap } from 'lucide-react';

export const HeroSection: React.FC = () => {
  const {
    searchQuery,
    setSearchQuery,
    selectedNeighborhood,
    setSelectedNeighborhood,
    radiusMiles,
    setRadiusMiles,
    setIsMapModalOpen,
    setIsNewItemModalOpen
  } = useApp();

  return (
    <section className="relative overflow-hidden bg-neutral-900 text-white border-b border-neutral-800">
      {/* Background Image with Scrim */}
      <div className="absolute inset-0 z-0">
        <img
          src="/src/assets/images/hero_local_market_1791629909923.jpg"
          alt="Neighborhood local marketplace square"
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover object-center opacity-40 mix-blend-luminosity filter contrast-125"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-neutral-950 via-neutral-950/80 to-neutral-950/40" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-20 lg:py-24">
        <div className="max-w-2xl space-y-6">
          
          {/* Subtle text kicker without static pills */}
          <div className="flex items-center gap-2 text-xs font-medium text-neutral-300">
            <span>Verified Neighborhood Commerce</span>
            <span aria-hidden="true">·</span>
            <span>Escrow Protected</span>
            <span aria-hidden="true">·</span>
            <span>Zero Platform Middlemen</span>
          </div>

          {/* Hero Headline */}
          <h1 className="font-display text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-white leading-[1.12] [text-wrap:balance]">
            Buy and sell goods with people in your neighborhood.
          </h1>

          <p className="text-base sm:text-lg text-neutral-300 leading-relaxed font-normal">
            Discover small-batch bakeries, local craft studios, rare plants, and neighbors trading quality pre-loved items within walking or cycling distance.
          </p>

          {/* Integrated Search & Local Filter Bar */}
          <div className="pt-2">
            <div className="bg-white/95 backdrop-blur-md rounded-xl p-2 shadow-xl border border-neutral-200/20 text-neutral-900 flex flex-col md:flex-row items-stretch gap-2">
              
              {/* Search text input */}
              <div className="flex-1 flex items-center gap-2.5 px-3 py-2 border-b md:border-b-0 md:border-r border-neutral-200">
                <Search className="w-4 h-4 text-neutral-400 shrink-0" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search sourdough, ceramics, cameras, plants..."
                  className="w-full text-sm bg-transparent outline-none text-neutral-900 placeholder:text-neutral-400"
                />
                {searchQuery && (
                  <button
                    onClick={() => setSearchQuery('')}
                    className="text-xs text-neutral-400 hover:text-neutral-700 px-1"
                  >
                    Clear
                  </button>
                )}
              </div>

              {/* Neighborhood select */}
              <div className="flex items-center gap-2 px-3 py-2 border-b md:border-b-0 md:border-r border-neutral-200 shrink-0">
                <MapPin className="w-4 h-4 text-neutral-500 shrink-0" />
                <select
                  value={selectedNeighborhood}
                  onChange={(e) => setSelectedNeighborhood(e.target.value)}
                  aria-label="Neighborhood filter"
                  className="text-xs sm:text-sm font-medium bg-transparent outline-none text-neutral-800 cursor-pointer pr-4"
                >
                  <option value="all">All Neighborhoods</option>
                  <option value="Eastside Arts District">Eastside Arts District</option>
                  <option value="Downtown Historic Core">Downtown Historic Core</option>
                  <option value="Greenwood Hill">Greenwood Hill</option>
                  <option value="Riverfront Quarter">Riverfront Quarter</option>
                  <option value="Southpark Commons">Southpark Commons</option>
                </select>
              </div>

              {/* Distance radius quick selector */}
              <div className="flex items-center justify-between px-3 py-2 gap-2 shrink-0">
                <div className="flex items-center gap-1.5 text-xs text-neutral-600 font-medium">
                  <SlidersHorizontal className="w-3.5 h-3.5 text-neutral-500" />
                  <span>Radius:</span>
                </div>
                <div className="flex items-center gap-1">
                  {[1, 3, 5, 10].map((m) => (
                    <button
                      key={m}
                      onClick={() => setRadiusMiles(m)}
                      className={`px-2 py-1 text-xs font-semibold rounded-md transition-colors ${
                        radiusMiles === m
                          ? 'bg-neutral-900 text-white'
                          : 'bg-neutral-100 text-neutral-700 hover:bg-neutral-200'
                      }`}
                    >
                      {m}m
                    </button>
                  ))}
                </div>
              </div>

              {/* Interactive Map Button */}
              <button
                onClick={() => setIsMapModalOpen(true)}
                className="px-4 py-2.5 bg-neutral-900 hover:bg-neutral-800 text-white rounded-lg text-xs font-semibold tracking-wide transition-colors flex items-center justify-center gap-1.5 shrink-0"
              >
                <span>View Map</span>
              </button>
            </div>
          </div>

          {/* Trust strip below search */}
          <div className="pt-2 flex flex-wrap items-center gap-x-6 gap-y-2 text-xs text-neutral-400">
            <div className="flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-neutral-300" />
              <span>Escrow holds payment until pickup QR is scanned</span>
            </div>
            <div className="flex items-center gap-1.5">
              <Zap className="w-4 h-4 text-neutral-300" />
              <span>Real-time buyer & seller chat with direct offers</span>
            </div>
            <button
              onClick={() => setIsNewItemModalOpen(true)}
              className="text-neutral-200 hover:text-white underline underline-offset-4 transition-colors"
            >
              List an item for free in 60s
            </button>
          </div>

        </div>
      </div>
    </section>
  );
};
