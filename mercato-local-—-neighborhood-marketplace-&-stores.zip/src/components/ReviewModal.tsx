import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { X, Star, ShieldCheck, Check } from 'lucide-react';

export const ReviewModal: React.FC = () => {
  const {
    isReviewModalOpen,
    closeReviewModal,
    reviewOrder,
    reviewRole,
    currentUser,
    submitReview
  } = useApp();

  const [rating, setRating] = useState<number>(5);
  const [comment, setComment] = useState<string>('');
  const [communication, setCommunication] = useState<number>(5);
  const [accuracy, setAccuracy] = useState<number>(5);
  const [punctuality, setPunctuality] = useState<number>(5);

  if (!isReviewModalOpen || !reviewOrder) return null;

  const targetName = reviewRole === 'buyer' ? reviewOrder.sellerName : reviewOrder.buyerName;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!comment.trim()) return;

    submitReview({
      authorName: currentUser.name,
      authorAvatar: currentUser.avatar,
      authorRole: reviewRole,
      targetId: reviewRole === 'buyer' ? reviewOrder.itemId : reviewOrder.buyerId,
      rating,
      comment: comment.trim(),
      verifiedPurchase: true,
      attributes: {
        communication,
        accuracy,
        punctuality
      }
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 overflow-y-auto bg-black/60 backdrop-blur-xs">
      <div
        className="relative w-full max-w-md bg-white rounded-2xl shadow-2xl border border-neutral-200 overflow-hidden my-auto p-6 space-y-5"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-neutral-200 pb-3">
          <div>
            <h3 className="font-display text-base font-bold text-neutral-900">
              {reviewRole === 'buyer' ? 'Review Local Seller' : 'Review Local Buyer'}
            </h3>
            <p className="text-xs text-neutral-500 mt-0.5">
              Order #{reviewOrder.id} · {reviewOrder.itemTitle}
            </p>
          </div>
          <button
            onClick={closeReviewModal}
            className="p-1 text-neutral-400 hover:text-neutral-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          
          {/* Target User Info */}
          <div className="flex items-center gap-2 text-xs text-neutral-700 bg-neutral-50 p-3 rounded-xl border border-neutral-200">
            <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>
              Rating <strong>{targetName}</strong> with verified transaction badge.
            </span>
          </div>

          {/* Overall Star Rating */}
          <div className="space-y-1.5 text-center py-2">
            <div className="text-xs font-semibold text-neutral-700">Overall Rating</div>
            <div className="flex items-center justify-center gap-2">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  key={star}
                  type="button"
                  onClick={() => setRating(star)}
                  className="p-1 transition-transform hover:scale-110"
                >
                  <Star
                    className={`w-7 h-7 ${
                      star <= rating
                        ? 'fill-amber-400 text-amber-400'
                        : 'text-neutral-300'
                    }`}
                  />
                </button>
              ))}
            </div>
            <div className="text-xs font-mono font-semibold text-neutral-700">
              {rating === 5 ? '5.0 — Outstanding Experience' : `${rating}.0 / 5.0`}
            </div>
          </div>

          {/* Sub-attributes */}
          <div className="space-y-2 pt-2 border-t border-neutral-100 text-xs">
            <div className="flex items-center justify-between">
              <span className="text-neutral-600">Communication & Responsiveness</span>
              <div className="flex gap-1">
                {[1, 2, 3, 4, 5].map((v) => (
                  <button
                    key={v}
                    type="button"
                    onClick={() => setCommunication(v)}
                    className={`w-6 h-6 rounded text-[11px] font-mono font-bold ${
                      communication === v
                        ? 'bg-neutral-900 text-white'
                        : 'bg-neutral-100 text-neutral-600'
                    }`}
                  >
                    {v}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-neutral-600">Listing Accuracy & Condition</span>
              <div className="flex gap-1">
                {[1, 2, 3, 4, 5].map((v) => (
                  <button
                    key={v}
                    type="button"
                    onClick={() => setAccuracy(v)}
                    className={`w-6 h-6 rounded text-[11px] font-mono font-bold ${
                      accuracy === v
                        ? 'bg-neutral-900 text-white'
                        : 'bg-neutral-100 text-neutral-600'
                    }`}
                  >
                    {v}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-neutral-600">Meetup Punctuality</span>
              <div className="flex gap-1">
                {[1, 2, 3, 4, 5].map((v) => (
                  <button
                    key={v}
                    type="button"
                    onClick={() => setPunctuality(v)}
                    className={`w-6 h-6 rounded text-[11px] font-mono font-bold ${
                      punctuality === v
                        ? 'bg-neutral-900 text-white'
                        : 'bg-neutral-100 text-neutral-600'
                    }`}
                  >
                    {v}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Comment */}
          <div className="space-y-1">
            <label className="text-xs font-semibold text-neutral-800 block">
              Written Community Feedback
            </label>
            <textarea
              rows={3}
              required
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              placeholder="Describe the packaging, meetup spot, product condition..."
              className="w-full text-xs p-3 border border-neutral-300 rounded-xl outline-none focus:border-neutral-900 transition-colors"
            />
          </div>

          {/* Submit button */}
          <button
            type="submit"
            className="w-full py-2.5 bg-neutral-900 hover:bg-neutral-800 text-white text-xs font-semibold rounded-xl transition-colors shadow-xs"
          >
            Publish Verified Review
          </button>

        </form>
      </div>
    </div>
  );
};
