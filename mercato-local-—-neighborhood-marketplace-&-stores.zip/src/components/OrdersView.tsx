import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  Package,
  Clock,
  ShieldCheck,
  CheckCircle2,
  QrCode,
  Star,
  MessageSquare,
  KeyRound,
  AlertCircle
} from 'lucide-react';
import { Order } from '../types';

export const OrdersView: React.FC = () => {
  const {
    orders,
    currentUser,
    verifyPickup,
    openReviewModal,
    openChatForItem,
    items
  } = useApp();

  const [activeTab, setActiveTab] = useState<'purchases' | 'sales'>('purchases');
  const [codeInput, setCodeInput] = useState<{ [orderId: string]: string }>({});
  const [verifyMessage, setVerifyMessage] = useState<{ [orderId: string]: string }>({});

  const myPurchases = orders.filter((o) => o.buyerId === currentUser.id);
  const mySales = orders.filter((o) => o.sellerId === currentUser.id);

  const displayOrders = activeTab === 'purchases' ? myPurchases : mySales;

  const handleVerifyCode = (orderId: string) => {
    const code = codeInput[orderId] || '';
    const res = verifyPickup(orderId, code);
    setVerifyMessage((prev) => ({ ...prev, [orderId]: res.message }));
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      
      {/* Title & Tab Switcher */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-neutral-200 pb-5">
        <div>
          <h1 className="font-display text-2xl font-bold text-neutral-900">
            Order History & Escrow Tracking
          </h1>
          <p className="text-xs text-neutral-500 mt-1">
            Real-time status, digital pickup passes, escrow releases, and community ratings.
          </p>
        </div>

        <div className="flex items-center gap-1 p-1 bg-neutral-100 rounded-lg self-start sm:self-auto">
          <button
            onClick={() => setActiveTab('purchases')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
              activeTab === 'purchases'
                ? 'bg-white text-neutral-900 shadow-xs'
                : 'text-neutral-600 hover:text-neutral-900'
            }`}
          >
            My Purchases ({myPurchases.length})
          </button>
          <button
            onClick={() => setActiveTab('sales')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
              activeTab === 'sales'
                ? 'bg-white text-neutral-900 shadow-xs'
                : 'text-neutral-600 hover:text-neutral-900'
            }`}
          >
            My Sales ({mySales.length})
          </button>
        </div>
      </div>

      {/* Orders List */}
      {displayOrders.length === 0 ? (
        <div className="py-16 text-center bg-white rounded-xl border border-neutral-200 p-8">
          <Package className="w-10 h-10 text-neutral-300 mx-auto mb-3" />
          <h3 className="font-display text-base font-semibold text-neutral-800">
            No {activeTab === 'purchases' ? 'purchases' : 'sales'} yet
          </h3>
          <p className="text-xs text-neutral-500 mt-1 max-w-sm mx-auto">
            {activeTab === 'purchases'
              ? 'Browse the neighborhood marketplace to discover goods near you.'
              : 'List items to begin receiving local pickup and courier orders.'}
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {displayOrders.map((order) => {
            const isPurchase = activeTab === 'purchases';
            const relatedItem = items.find((i) => i.id === order.itemId);

            return (
              <div
                key={order.id}
                className="bg-white rounded-xl border border-neutral-200 overflow-hidden shadow-xs hover:border-neutral-300 transition-colors"
              >
                {/* Order Top Bar */}
                <div className="p-4 bg-neutral-50/70 border-b border-neutral-200 flex flex-wrap items-center justify-between gap-3 text-xs">
                  <div className="flex items-center gap-3">
                    <span className="font-mono font-bold text-neutral-900">{order.id}</span>
                    <span className="text-neutral-400">·</span>
                    <span className="text-neutral-500">
                      {new Date(order.createdAt).toLocaleDateString('en-US', {
                        month: 'short',
                        day: 'numeric'
                      })}
                    </span>
                  </div>

                  {/* Status pill-free unboxed tag */}
                  <div className="flex items-center gap-2">
                    {order.status === 'escrow_held' && (
                      <span className="text-amber-700 bg-amber-50 px-2.5 py-1 rounded text-xs font-semibold flex items-center gap-1.5">
                        <Clock className="w-3.5 h-3.5" />
                        <span>Escrow Held · Seller Preparing</span>
                      </span>
                    )}
                    {order.status === 'ready_for_pickup' && (
                      <span className="text-indigo-700 bg-indigo-50 px-2.5 py-1 rounded text-xs font-semibold flex items-center gap-1.5">
                        <QrCode className="w-3.5 h-3.5" />
                        <span>Ready for Pickup</span>
                      </span>
                    )}
                    {order.status === 'completed' && (
                      <span className="text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded text-xs font-semibold flex items-center gap-1.5">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Completed & Escrow Released</span>
                      </span>
                    )}
                  </div>
                </div>

                {/* Order Content */}
                <div className="p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
                  
                  {/* Left: Product & Counterparty Details */}
                  <div className="flex items-center gap-4 min-w-0">
                    <img
                      src={order.itemImage}
                      alt={order.itemTitle}
                      referrerPolicy="no-referrer"
                      className="w-16 h-16 rounded-xl object-cover bg-neutral-100 shrink-0 border border-neutral-200"
                    />
                    <div className="space-y-1 min-w-0">
                      <h3 className="font-semibold text-neutral-900 text-sm leading-snug">
                        {order.itemTitle}
                      </h3>
                      <div className="text-xs text-neutral-500 flex items-center gap-1.5">
                        <span>
                          {isPurchase ? `Seller: ${order.sellerName}` : `Buyer: ${order.buyerName}`}
                        </span>
                        <span>·</span>
                        <span>Qty: {order.quantity}</span>
                      </div>
                      <div className="text-xs text-neutral-400">
                        Meetup: {order.pickupAddress}
                      </div>
                    </div>
                  </div>

                  {/* Right: Price & Digital Pass / Verification Action */}
                  <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 shrink-0 w-full md:w-auto justify-end">
                    
                    <div className="text-right">
                      <div className="text-[11px] text-neutral-400 uppercase tracking-wide">
                        Total Amount
                      </div>
                      <div className="font-mono tabular-nums text-lg font-bold text-neutral-900">
                        ${order.totalAmount.toFixed(2)}
                      </div>
                    </div>

                    {/* Buyer view of code */}
                    {isPurchase && (
                      <div className="p-2.5 bg-neutral-100 rounded-lg text-center border border-neutral-200">
                        <div className="text-[10px] text-neutral-500 font-medium">Pickup Pass Code</div>
                        <div className="font-mono text-sm font-bold text-neutral-900 tracking-wider">
                          {order.pickupVerificationCode}
                        </div>
                      </div>
                    )}

                    {/* Actions cluster */}
                    <div className="flex flex-wrap items-center gap-2">
                      {/* Contact in Chat */}
                      {relatedItem && (
                        <button
                          onClick={() => openChatForItem(relatedItem)}
                          className="p-2 text-neutral-600 hover:text-neutral-900 hover:bg-neutral-100 border border-neutral-200 rounded-lg transition-colors"
                          title="Open chat"
                        >
                          <MessageSquare className="w-4 h-4" />
                        </button>
                      )}

                      {/* Seller Verification Input */}
                      {!isPurchase && order.status !== 'completed' && (
                        <div className="flex items-center gap-1.5">
                          <input
                            type="text"
                            placeholder="Buyer 6-digit Code"
                            value={codeInput[order.id] || ''}
                            onChange={(e) =>
                              setCodeInput({ ...codeInput, [order.id]: e.target.value })
                            }
                            className="text-xs font-mono px-2.5 py-1.5 border border-neutral-300 rounded-lg w-32 outline-none"
                          />
                          <button
                            onClick={() => handleVerifyCode(order.id)}
                            className="px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold rounded-lg transition-colors flex items-center gap-1 shadow-xs"
                          >
                            <KeyRound className="w-3.5 h-3.5" />
                            <span>Verify</span>
                          </button>
                        </div>
                      )}

                      {/* Review Buttons */}
                      {order.status === 'completed' && (
                        <div>
                          {isPurchase ? (
                            order.hasBuyerReviewed ? (
                              <span className="text-xs text-neutral-400 font-medium flex items-center gap-1">
                                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                                <span>Reviewed</span>
                              </span>
                            ) : (
                              <button
                                onClick={() => openReviewModal(order, 'buyer')}
                                className="px-3 py-1.5 text-xs font-semibold text-neutral-900 bg-neutral-100 hover:bg-neutral-200 rounded-lg transition-colors flex items-center gap-1"
                              >
                                <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                                <span>Review Seller</span>
                              </button>
                            )
                          ) : order.hasSellerReviewed ? (
                            <span className="text-xs text-neutral-400 font-medium flex items-center gap-1">
                              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                              <span>Reviewed</span>
                            </span>
                          ) : (
                            <button
                              onClick={() => openReviewModal(order, 'seller')}
                              className="px-3 py-1.5 text-xs font-semibold text-neutral-900 bg-neutral-100 hover:bg-neutral-200 rounded-lg transition-colors flex items-center gap-1"
                            >
                              <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                              <span>Review Buyer</span>
                            </button>
                          )}
                        </div>
                      )}
                    </div>

                  </div>
                </div>

                {/* Seller verification feedback banner if any */}
                {verifyMessage[order.id] && (
                  <div className="px-5 py-2 bg-neutral-100 text-xs text-neutral-800 border-t border-neutral-200 font-medium">
                    {verifyMessage[order.id]}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

    </div>
  );
};
