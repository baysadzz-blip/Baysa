import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  X,
  MapPin,
  ShieldCheck,
  MessageSquare,
  Tag,
  Truck,
  CheckCircle2,
  Clock,
  Star,
  Share2,
  AlertCircle
} from 'lucide-react';

export const ItemDetailModal: React.FC = () => {
  const {
    selectedItem,
    setSelectedItem,
    openCheckout,
    openChatForItem,
    reviews
  } = useApp();

  const [isOfferMode, setIsOfferMode] = useState<boolean>(false);
  const [offerPrice, setOfferPrice] = useState<string>('');
  const [copiedLink, setCopiedLink] = useState<boolean>(false);

  if (!selectedItem) return null;

  const itemReviews = reviews.filter((r) => r.targetId === selectedItem.id);

  const handleSendOffer = (e: React.FormEvent) => {
    e.preventDefault();
    const parsed = parseFloat(offerPrice);
    if (!parsed || parsed <= 0) return;

    // Close detail modal, open chat with an offer
    setSelectedItem(null);
    openChatForItem(
      selectedItem,
      `I would like to offer $${parsed} for "${selectedItem.title}". Does that work for you?`
    );
  };

  const handleShare = () => {
    navigator.clipboard?.writeText(window.location.href);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto bg-black/60 backdrop-blur-xs">
      <div
        className="relative w-full max-w-4xl bg-white rounded-2xl shadow-2xl border border-neutral-200 overflow-hidden my-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top bar controls */}
        <div className="absolute top-4 right-4 z-20 flex items-center gap-2">
          <button
            onClick={handleShare}
            className="p-2 rounded-full bg-white/90 backdrop-blur-md hover:bg-white text-neutral-700 hover:text-neutral-900 shadow-xs transition-colors"
            title="Share listing"
          >
            <Share2 className="w-4 h-4" />
          </button>
          <button
            onClick={() => setSelectedItem(null)}
            className="p-2 rounded-full bg-white/90 backdrop-blur-md hover:bg-white text-neutral-700 hover:text-neutral-900 shadow-xs transition-colors"
            title="Close modal"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {copiedLink && (
          <div className="absolute top-16 right-4 z-20 bg-neutral-900 text-white text-xs px-3 py-1.5 rounded-lg shadow-md">
            Link copied to clipboard!
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 max-h-[85vh] overflow-y-auto">
          
          {/* Left Column: Image Gallery */}
          <div className="bg-neutral-100 flex flex-col justify-center relative min-h-[320px] md:min-h-full">
            <img
              src={selectedItem.image}
              alt={selectedItem.title}
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover max-h-[500px]"
            />
            <div className="absolute bottom-4 left-4 bg-black/60 backdrop-blur-md text-white text-xs px-3 py-1.5 rounded-lg flex items-center gap-2">
              <span className="font-medium">{selectedItem.condition}</span>
              <span aria-hidden="true">·</span>
              <span className="font-mono tabular-nums">{selectedItem.stock} units in stock</span>
            </div>
          </div>

          {/* Right Column: Contiguous Purchase Module */}
          <div className="p-6 sm:p-8 flex flex-col justify-between space-y-6">
            
            <div className="space-y-4">
              
              {/* Category & Location metadata */}
              <div className="flex items-center gap-2 text-xs text-neutral-500 font-medium">
                <span className="text-neutral-800">{selectedItem.category}</span>
                <span aria-hidden="true">·</span>
                <span className="flex items-center gap-1 text-neutral-700">
                  <MapPin className="w-3.5 h-3.5 text-neutral-400" />
                  <span className="font-mono tabular-nums">{selectedItem.distanceMiles} miles</span> away
                </span>
                <span aria-hidden="true">·</span>
                <span>{selectedItem.neighborhood}</span>
              </div>

              {/* Title */}
              <h2 className="font-display text-2xl font-bold text-neutral-900 leading-tight">
                {selectedItem.title}
              </h2>

              {/* Price display */}
              <div className="flex items-baseline gap-3">
                <span className="font-mono tabular-nums text-3xl font-bold text-neutral-900">
                  ${selectedItem.price}
                </span>
                {selectedItem.originalPrice && (
                  <span className="font-mono tabular-nums text-base text-neutral-400 line-through">
                    ${selectedItem.originalPrice}
                  </span>
                )}
                <span className="text-xs text-emerald-700 font-medium bg-emerald-50 px-2 py-0.5 rounded">
                  Local Price Guarantee
                </span>
              </div>

              {/* Description */}
              <div className="pt-2 text-sm text-neutral-600 leading-relaxed">
                <p>{selectedItem.description}</p>
              </div>

              {/* Pickup & Delivery Info */}
              <div className="p-3.5 bg-neutral-50 rounded-xl border border-neutral-200 text-xs space-y-2">
                <div className="flex items-start gap-2 text-neutral-800">
                  <MapPin className="w-4 h-4 text-neutral-500 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-semibold">Local Pickup: </span>
                    <span className="text-neutral-600">{selectedItem.pickupAddress}</span>
                  </div>
                </div>

                <div className="flex items-start gap-2 text-neutral-800">
                  <Truck className="w-4 h-4 text-neutral-500 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-semibold">Available Fulfillment: </span>
                    <span className="text-neutral-600">
                      {selectedItem.deliveryOptions
                        .map((d) => (d === 'local_pickup' ? 'Self Pickup' : d === 'same_day_dropoff' ? 'Same-Day Dropoff' : 'Courier'))
                        .join(' · ')}
                    </span>
                  </div>
                </div>
              </div>

              {/* Seller Trust Profile */}
              <div className="flex items-center justify-between p-3 border border-neutral-200 rounded-xl">
                <div className="flex items-center gap-3">
                  <img
                    src={selectedItem.sellerAvatar}
                    alt={selectedItem.sellerName}
                    referrerPolicy="no-referrer"
                    className="w-10 h-10 rounded-full object-cover border border-neutral-200"
                  />
                  <div>
                    <div className="text-xs font-bold text-neutral-900">{selectedItem.sellerName}</div>
                    <div className="flex items-center gap-1.5 text-[11px] text-neutral-500 mt-0.5">
                      <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                      <span className="font-mono tabular-nums font-semibold">{selectedItem.sellerRating}</span>
                      <span>verified trust score</span>
                    </div>
                  </div>
                </div>

                <button
                  onClick={() => {
                    setSelectedItem(null);
                    openChatForItem(selectedItem);
                  }}
                  className="px-3 py-1.5 text-xs font-semibold text-neutral-800 hover:bg-neutral-100 border border-neutral-200 rounded-lg transition-colors flex items-center gap-1"
                >
                  <MessageSquare className="w-3.5 h-3.5" />
                  <span>Chat</span>
                </button>
              </div>

            </div>

            {/* Contiguous Purchase Action Module */}
            <div className="space-y-3 pt-4 border-t border-neutral-100">
              
              {!isOfferMode ? (
                <div className="grid grid-cols-2 gap-3">
                  <button
                    onClick={() => {
                      setIsOfferMode(true);
                      setOfferPrice((selectedItem.price * 0.9).toFixed(0));
                    }}
                    className="px-4 py-2.5 text-xs font-semibold text-neutral-800 bg-neutral-100 hover:bg-neutral-200 rounded-lg transition-colors flex items-center justify-center gap-1.5"
                  >
                    <Tag className="w-3.5 h-3.5" />
                    <span>Make Offer</span>
                  </button>

                  <button
                    onClick={() => {
                      const itemToCheckout = selectedItem;
                      setSelectedItem(null);
                      openCheckout(itemToCheckout);
                    }}
                    className="px-4 py-2.5 text-xs font-semibold text-white bg-neutral-900 hover:bg-neutral-800 rounded-lg transition-colors flex items-center justify-center gap-1.5 shadow-xs"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Secure Checkout</span>
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSendOffer} className="space-y-2 p-3 bg-neutral-50 rounded-xl border border-neutral-200">
                  <div className="flex items-center justify-between text-xs font-medium text-neutral-700">
                    <span>Propose an Offer</span>
                    <button
                      type="button"
                      onClick={() => setIsOfferMode(false)}
                      className="text-neutral-400 hover:text-neutral-700"
                    >
                      Cancel
                    </button>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-bold text-neutral-600">$</span>
                    <input
                      type="number"
                      step="1"
                      min="1"
                      value={offerPrice}
                      onChange={(e) => setOfferPrice(e.target.value)}
                      placeholder="Enter amount"
                      className="w-full text-sm font-mono px-3 py-1.5 bg-white border border-neutral-300 rounded-lg outline-none"
                    />
                    <button
                      type="submit"
                      className="px-4 py-1.5 bg-neutral-900 hover:bg-neutral-800 text-white text-xs font-semibold rounded-lg shrink-0"
                    >
                      Send in Chat
                    </button>
                  </div>
                  <div className="text-[11px] text-neutral-500 flex items-center gap-1">
                    <AlertCircle className="w-3 h-3 text-neutral-400" />
                    <span>Seller can accept, decline, or counter in direct chat.</span>
                  </div>
                </form>
              )}

              {/* Escrow Guarantee Note */}
              <div className="flex items-center justify-center gap-1.5 text-[11px] text-neutral-500 text-center">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                <span>Payment held safely in escrow until you scan the pickup QR pass.</span>
              </div>

            </div>

          </div>

        </div>

        {/* Reviews Section at bottom of modal */}
        {itemReviews.length > 0 && (
          <div className="border-t border-neutral-200 p-6 sm:p-8 bg-neutral-50/50">
            <h4 className="font-display text-sm font-bold text-neutral-900 mb-3">
              Verified Buyer Reviews ({itemReviews.length})
            </h4>
            <div className="space-y-3">
              {itemReviews.map((rev) => (
                <div key={rev.id} className="bg-white p-3.5 rounded-xl border border-neutral-200 text-xs space-y-1.5">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <img
                        src={rev.authorAvatar}
                        alt={rev.authorName}
                        referrerPolicy="no-referrer"
                        className="w-5 h-5 rounded-full object-cover"
                      />
                      <span className="font-semibold text-neutral-900">{rev.authorName}</span>
                      {rev.verifiedPurchase && (
                        <span className="text-[10px] text-emerald-700 bg-emerald-50 px-1.5 py-0.2 rounded font-medium">
                          Verified Local Purchase
                        </span>
                      )}
                    </div>
                    <div className="flex items-center gap-1 text-amber-500 font-mono">
                      <Star className="w-3 h-3 fill-amber-400" />
                      <span>{rev.rating}.0</span>
                    </div>
                  </div>
                  <p className="text-neutral-600 leading-relaxed">{rev.comment}</p>
                </div>
              ))}
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
