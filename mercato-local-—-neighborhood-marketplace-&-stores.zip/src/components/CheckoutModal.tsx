import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  X,
  ShieldCheck,
  CreditCard,
  Wallet,
  CheckCircle2,
  MapPin,
  QrCode,
  Truck,
  ArrowRight
} from 'lucide-react';
import { DeliveryType, Order } from '../types';

export const CheckoutModal: React.FC = () => {
  const {
    isCheckoutModalOpen,
    closeCheckout,
    checkoutItem,
    checkoutCustomPrice,
    currentUser,
    createOrder,
    setCurrentView
  } = useApp();

  const [quantity, setQuantity] = useState<number>(1);
  const [deliveryType, setDeliveryType] = useState<DeliveryType>('local_pickup');
  const [paymentMethod, setPaymentMethod] = useState<'apple_pay' | 'credit_card' | 'local_wallet' | 'cash_on_pickup'>('apple_pay');
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [confirmedOrder, setConfirmedOrder] = useState<Order | null>(null);

  if (!isCheckoutModalOpen || !checkoutItem) return null;

  const unitPrice = checkoutCustomPrice !== null ? checkoutCustomPrice : checkoutItem.price;
  const subtotal = unitPrice * quantity;
  const localServiceFee = 1.50; // nominal local platform escrow fee
  const total = subtotal + (deliveryType === 'neighborhood_courier' ? 4.00 : deliveryType === 'same_day_dropoff' ? 6.00 : 0) + localServiceFee;

  const handleCompletePayment = (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);

    setTimeout(() => {
      const order = createOrder({
        item: checkoutItem,
        quantity,
        paymentMethod,
        deliveryType,
        unitPrice
      });
      setIsProcessing(false);
      setConfirmedOrder(order);
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto bg-black/60 backdrop-blur-xs">
      <div
        className="relative w-full max-w-lg bg-white rounded-2xl shadow-2xl border border-neutral-200 overflow-hidden my-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 border-b border-neutral-200 flex items-center justify-between bg-neutral-50/80">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-md bg-neutral-900 text-white flex items-center justify-center font-bold text-xs">
              M
            </div>
            <h3 className="font-display text-sm font-bold text-neutral-900">
              {confirmedOrder ? 'Order Confirmed' : 'Mercato Escrow Checkout'}
            </h3>
          </div>
          <button
            onClick={closeCheckout}
            className="p-1 rounded-md text-neutral-400 hover:text-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Confirmation Screen */}
        {confirmedOrder ? (
          <div className="p-6 space-y-6 text-center">
            
            <div className="w-14 h-14 bg-emerald-100 text-emerald-700 rounded-full flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-8 h-8" />
            </div>

            <div className="space-y-1">
              <h3 className="font-display text-xl font-bold text-neutral-900">
                Payment Held in Escrow!
              </h3>
              <p className="text-xs text-neutral-500">
                Order #{confirmedOrder.id} is confirmed. Funds are protected until verified.
              </p>
            </div>

            {/* Pickup Pass Card with QR Code Representation */}
            <div className="p-5 bg-neutral-50 rounded-xl border border-neutral-200 text-left space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-neutral-200 text-xs">
                <span className="font-semibold text-neutral-700">Pickup Pass & Code</span>
                <span className="font-mono tabular-nums text-emerald-700 font-bold bg-emerald-50 px-2 py-0.5 rounded">
                  ESCROW ACTIVE
                </span>
              </div>

              <div className="flex items-center justify-center py-2">
                <div className="p-3 bg-white rounded-xl border-2 border-dashed border-neutral-300 text-center space-y-2">
                  <QrCode className="w-20 h-20 mx-auto text-neutral-900" />
                  <div className="text-[10px] text-neutral-400 uppercase tracking-widest font-mono">
                    Scan At Pickup
                  </div>
                  <div className="text-xl font-mono font-bold tracking-widest text-neutral-900 bg-neutral-100 px-3 py-1 rounded">
                    {confirmedOrder.pickupVerificationCode}
                  </div>
                </div>
              </div>

              <div className="text-xs space-y-1.5 text-neutral-600">
                <div className="flex items-start gap-2">
                  <MapPin className="w-4 h-4 text-neutral-500 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-semibold text-neutral-900">Meetup Location: </span>
                    <span>{confirmedOrder.pickupAddress}</span>
                  </div>
                </div>
                <div className="flex items-start gap-2">
                  <ShieldCheck className="w-4 h-4 text-neutral-500 shrink-0 mt-0.5" />
                  <div>
                    <span>Show this 6-digit code or QR code to {confirmedOrder.sellerName} once you have inspected your item.</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <button
                onClick={() => {
                  closeCheckout();
                  setCurrentView('orders');
                }}
                className="w-full py-2.5 bg-neutral-900 hover:bg-neutral-800 text-white text-xs font-semibold rounded-lg transition-colors flex items-center justify-center gap-1.5 shadow-xs"
              >
                <span>Track in My Orders</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

          </div>
        ) : (
          /* Checkout Form */
          <form onSubmit={handleCompletePayment} className="p-6 space-y-5">
            
            {/* Item Summary */}
            <div className="flex items-center gap-3 p-3 bg-neutral-50 rounded-xl border border-neutral-200">
              <img
                src={checkoutItem.image}
                alt={checkoutItem.title}
                referrerPolicy="no-referrer"
                className="w-14 h-14 rounded-lg object-cover bg-neutral-200 shrink-0"
              />
              <div className="flex-1 min-w-0">
                <h4 className="text-xs font-semibold text-neutral-900 truncate">
                  {checkoutItem.title}
                </h4>
                <div className="text-[11px] text-neutral-500 mt-0.5">
                  Seller: {checkoutItem.sellerName}
                </div>
                <div className="flex items-center gap-2 mt-1">
                  <span className="font-mono tabular-nums text-sm font-bold text-neutral-900">
                    ${unitPrice}
                  </span>
                  {checkoutCustomPrice !== null && (
                    <span className="text-[10px] bg-neutral-200 text-neutral-800 px-1.5 py-0.2 rounded font-medium">
                      Agreed Offer Price
                    </span>
                  )}
                </div>
              </div>

              {/* Quantity selector */}
              <div className="flex items-center border border-neutral-300 rounded-lg bg-white shrink-0">
                <button
                  type="button"
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="px-2 py-1 text-xs text-neutral-600 hover:text-neutral-900"
                >
                  -
                </button>
                <span className="font-mono text-xs px-2 font-semibold">{quantity}</span>
                <button
                  type="button"
                  onClick={() => setQuantity(Math.min(checkoutItem.stock, quantity + 1))}
                  className="px-2 py-1 text-xs text-neutral-600 hover:text-neutral-900"
                >
                  +
                </button>
              </div>
            </div>

            {/* Delivery Method Selector */}
            <div className="space-y-2">
              <label className="text-xs font-semibold text-neutral-900 block">
                Fulfillment Mode
              </label>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { id: 'local_pickup', label: 'Local Pickup', fee: 'Free' },
                  { id: 'neighborhood_courier', label: 'Local Courier', fee: '+$4.00' },
                  { id: 'same_day_dropoff', label: 'Same-Day Drop', fee: '+$6.00' }
                ].map((mode) => (
                  <button
                    key={mode.id}
                    type="button"
                    onClick={() => setDeliveryType(mode.id as DeliveryType)}
                    className={`p-2 rounded-xl border text-left transition-all ${
                      deliveryType === mode.id
                        ? 'border-neutral-900 bg-neutral-900 text-white'
                        : 'border-neutral-200 bg-white text-neutral-700 hover:bg-neutral-50'
                    }`}
                  >
                    <div className="text-xs font-bold leading-tight">{mode.label}</div>
                    <div className="text-[10px] opacity-80 font-mono mt-0.5">{mode.fee}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* Payment Method Selector */}
            <div className="space-y-2">
              <label className="text-xs font-semibold text-neutral-900 block">
                Payment Method (Escrow Secured)
              </label>
              <div className="space-y-1.5">
                {[
                  {
                    id: 'apple_pay',
                    title: 'Apple Pay / Digital Wallet',
                    desc: 'Fast biometric authorization',
                    icon: CreditCard
                  },
                  {
                    id: 'credit_card',
                    title: 'Credit / Debit Card (Stripe Escrow)',
                    desc: 'Instant hold, release on pickup scan',
                    icon: CreditCard
                  },
                  {
                    id: 'local_wallet',
                    title: `Mercato Local Balance ($${currentUser.walletBalance.toFixed(2)})`,
                    desc: 'Deduct from neighborhood wallet',
                    icon: Wallet
                  },
                  {
                    id: 'cash_on_pickup',
                    title: 'Cash on Verified Meetup',
                    desc: 'Safe public spot exchange',
                    icon: ShieldCheck
                  }
                ].map((pm) => {
                  const Icon = pm.icon;
                  return (
                    <label
                      key={pm.id}
                      className={`flex items-center justify-between p-2.5 rounded-xl border cursor-pointer transition-colors ${
                        paymentMethod === pm.id
                          ? 'border-neutral-900 bg-neutral-50'
                          : 'border-neutral-200 hover:bg-neutral-50/50'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <input
                          type="radio"
                          name="payment"
                          checked={paymentMethod === pm.id}
                          onChange={() => setPaymentMethod(pm.id as any)}
                          className="text-neutral-900 focus:ring-neutral-900"
                        />
                        <div>
                          <div className="text-xs font-semibold text-neutral-900">{pm.title}</div>
                          <div className="text-[11px] text-neutral-500">{pm.desc}</div>
                        </div>
                      </div>
                      <Icon className="w-4 h-4 text-neutral-400 shrink-0" />
                    </label>
                  );
                })}
              </div>
            </div>

            {/* Order Price Breakdown */}
            <div className="p-3 bg-neutral-50 rounded-xl border border-neutral-200 text-xs space-y-1 font-mono">
              <div className="flex justify-between text-neutral-600">
                <span>Subtotal ({quantity} item)</span>
                <span className="tabular-nums">${subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-neutral-600">
                <span>Escrow Guarantee Fee</span>
                <span className="tabular-nums">${localServiceFee.toFixed(2)}</span>
              </div>
              {deliveryType !== 'local_pickup' && (
                <div className="flex justify-between text-neutral-600">
                  <span>Local Dispatch</span>
                  <span className="tabular-nums">
                    ${(deliveryType === 'neighborhood_courier' ? 4 : 6).toFixed(2)}
                  </span>
                </div>
              )}
              <div className="pt-2 border-t border-neutral-200 flex justify-between font-bold text-neutral-900 text-sm">
                <span>Total Amount</span>
                <span className="tabular-nums">${total.toFixed(2)}</span>
              </div>
            </div>

            {/* Escrow Guarantee Statement */}
            <div className="flex items-center gap-2 text-[11px] text-neutral-600 bg-emerald-50/80 p-2.5 rounded-xl border border-emerald-200">
              <ShieldCheck className="w-4 h-4 text-emerald-700 shrink-0" />
              <span>
                <strong>Buyer Protection Guarantee:</strong> Seller is not paid until you inspect the item and reveal your 6-digit code.
              </span>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={isProcessing}
              className="w-full py-3 bg-neutral-900 hover:bg-neutral-800 disabled:opacity-50 text-white font-semibold text-xs rounded-xl transition-colors shadow-xs flex items-center justify-center gap-2"
            >
              {isProcessing ? (
                <>
                  <div className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  <span>Authorizing Escrow Vault...</span>
                </>
              ) : (
                <>
                  <ShieldCheck className="w-4 h-4" />
                  <span>Lock Escrow & Place Order (${total.toFixed(2)})</span>
                </>
              )}
            </button>

          </form>
        )}

      </div>
    </div>
  );
};
